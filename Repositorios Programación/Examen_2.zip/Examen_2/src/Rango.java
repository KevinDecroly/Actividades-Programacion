public enum Rango {
    GENNIN,
    CHUNNIN,
    JONNIN,
    AMBU,
    KAGE
}
