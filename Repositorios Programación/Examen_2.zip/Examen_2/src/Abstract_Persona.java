import java.time.LocalDate;

public class Abstract_Persona {
    private String nombreabs;
    private LocalDate fechaNacimiento;
    private String DNI;
    private String direccion;
    private String Ncontrato;
}
